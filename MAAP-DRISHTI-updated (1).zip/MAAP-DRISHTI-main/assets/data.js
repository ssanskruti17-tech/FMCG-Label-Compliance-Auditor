/* ==========================================================================
   LabelGuard — hardcoded demo data
   Everything here stands in for the real edge engine + central repository.
   ========================================================================== */

const OFFICER = {
  name: "R. Mehta",
  id: "LM-OFF-2291",
  station: "Pune Circle Office",
};

const MINISTRY_USER = {
  name: "S. Deshpande",
  id: "DoCA-MIN-014",
  station: "Dept. of Consumer Affairs, Pune Division",
};

/* Headline numbers are *derived* from DAILY_SERIES below (30-day window sums to 1,248 / 187).
   These per-range values can't be derived from scan counts, so they are stated here. */
const RANGE_META = {
  7:  { officers: 31, officersDelta: 2,  scanSecs: 47, scanSecsDelta: -2 },
  30: { officers: 42, officersDelta: 3,  scanSecs: 48, scanSecsDelta: -3 },
  90: { officers: 58, officersDelta: 9,  scanSecs: 51, scanSecsDelta: -5 },
};

const LAST_SYNC = "28 Sep 2026, 11:50 IST";

const VIOLATION_CATEGORIES = [
  { label: "MRP font too small", pct: 38 },
  { label: "Net quantity — unit missing", pct: 22 },
  { label: "Mfg/packing date unreadable", pct: 18 },
  { label: "Manufacturer address missing", pct: 14 },
  { label: "Other declarations", pct: 8 },
];

/* status: "verify" | "flag" | "brass"  (compliant / violation / needs re-inspection) */
const SCANS_FEATURED = [
  { id: "SCAN-10234", product: "Sunrise Refined Sunflower Oil, 1 L", manufacturer: "Sunrise Agro Pvt Ltd", officer: "R. Mehta", date: "28 Sep 2026, 11:42", status: "flag", issues: 2 },
  { id: "SCAN-10233", product: "Tanishq Basmati Rice, 5 kg", manufacturer: "Tanishq Foods Pvt Ltd", officer: "R. Mehta", date: "28 Sep 2026, 10:15", status: "verify", issues: 0 },
  { id: "SCAN-10232", product: "Shudh Toor Dal, 1 kg", manufacturer: "Shudh Grains Co.", officer: "A. Khan", date: "27 Sep 2026, 16:30", status: "brass", issues: 1 },
  { id: "SCAN-10231", product: "FreshGlow Herbal Shampoo, 340 ml", manufacturer: "FreshGlow Cosmetics", officer: "A. Khan", date: "27 Sep 2026, 14:05", status: "verify", issues: 0 },
  { id: "SCAN-10230", product: "Royal Chakki Atta, 10 kg", manufacturer: "Royal Mills Ltd", officer: "R. Mehta", date: "27 Sep 2026, 11:20", status: "flag", issues: 3 },
  { id: "SCAN-10229", product: "Meadow Fresh Toned Milk, 500 ml", manufacturer: "Meadow Dairy Coop", officer: "P. Iyer", date: "26 Sep 2026, 18:47", status: "verify", issues: 0 },
  { id: "SCAN-10228", product: "Sparkle Dish Wash Bar, 700 g", manufacturer: "Sparkle Home Care", officer: "P. Iyer", date: "26 Sep 2026, 15:12", status: "flag", issues: 1 },
  { id: "SCAN-10227", product: "Village Jaggery Powder, 900 g", manufacturer: "Village Agro Foods", officer: "A. Khan", date: "26 Sep 2026, 09:58", status: "verify", issues: 0 },
];

/* Older inspections, compact form: [product, manufacturer, officer, date, status, issues] */
const SCANS_OLDER = [
  ["Golden Harvest Poha, 500 g", "Golden Harvest Foods", "P. Iyer", "26 Sep 2026, 09:12", "verify", 0],
  ["Pure Drop Packaged Water, 1 L", "Pure Drop Beverages", "S. Patil", "25 Sep 2026, 17:40", "flag", 2],
  ["Amrut Gold Tea, 250 g", "Amrut Tea Estates", "N. Joshi", "25 Sep 2026, 15:22", "verify", 0],
  ["Royal Chakki Atta, 5 kg", "Royal Mills Ltd", "R. Mehta", "25 Sep 2026, 12:05", "flag", 2],
  ["Kesari Pure Ghee, 500 ml", "Kesari Dairy Products", "A. Khan", "25 Sep 2026, 10:31", "verify", 0],
  ["Neelkamal Instant Noodles, 280 g", "Neelkamal Foods", "P. Iyer", "24 Sep 2026, 16:48", "brass", 1],
  ["Sunrise Mustard Oil, 500 ml", "Sunrise Agro Pvt Ltd", "S. Patil", "24 Sep 2026, 14:10", "flag", 1],
  ["Shudh Besan, 500 g", "Shudh Grains Co.", "A. Khan", "24 Sep 2026, 11:55", "verify", 0],
  ["FreshGlow Face Wash, 100 ml", "FreshGlow Cosmetics", "N. Joshi", "24 Sep 2026, 09:30", "verify", 0],
  ["Sparkle Floor Cleaner, 1 L", "Sparkle Home Care", "R. Mehta", "23 Sep 2026, 17:15", "flag", 3],
  ["Meadow Fresh Curd, 400 g", "Meadow Dairy Coop", "P. Iyer", "23 Sep 2026, 15:02", "verify", 0],
  ["Golden Harvest Cornflakes, 475 g", "Golden Harvest Foods", "S. Patil", "23 Sep 2026, 12:44", "flag", 1],
  ["Village Rock Salt, 1 kg", "Village Agro Foods", "A. Khan", "23 Sep 2026, 10:20", "verify", 0],
  ["Pure Drop Soda, 750 ml", "Pure Drop Beverages", "N. Joshi", "22 Sep 2026, 16:05", "brass", 1],
  ["Amrut Gold Coffee Powder, 200 g", "Amrut Tea Estates", "R. Mehta", "22 Sep 2026, 13:38", "verify", 0],
  ["Kesari Paneer, 200 g", "Kesari Dairy Products", "P. Iyer", "22 Sep 2026, 11:10", "verify", 0],
  ["Royal Chakki Multigrain Atta, 5 kg", "Royal Mills Ltd", "A. Khan", "21 Sep 2026, 15:50", "flag", 2],
  ["Neelkamal Vermicelli, 400 g", "Neelkamal Foods", "S. Patil", "21 Sep 2026, 12:25", "verify", 0],
  ["Sparkle Detergent Powder, 2 kg", "Sparkle Home Care", "N. Joshi", "20 Sep 2026, 17:02", "verify", 0],
  ["Sunrise Groundnut Oil, 1 L", "Sunrise Agro Pvt Ltd", "R. Mehta", "20 Sep 2026, 14:36", "flag", 2],
  ["FreshGlow Body Lotion, 200 ml", "FreshGlow Cosmetics", "P. Iyer", "19 Sep 2026, 16:18", "verify", 0],
  ["Shudh Moong Dal, 1 kg", "Shudh Grains Co.", "A. Khan", "19 Sep 2026, 11:42", "verify", 0],
  ["Village Sugar, 2 kg", "Village Agro Foods", "S. Patil", "18 Sep 2026, 15:09", "verify", 0],
  ["Golden Harvest Muesli, 500 g", "Golden Harvest Foods", "N. Joshi", "18 Sep 2026, 12:51", "brass", 1],
  ["Pure Drop Mineral Water, 2 L", "Pure Drop Beverages", "R. Mehta", "17 Sep 2026, 16:27", "flag", 1],
  ["Meadow Fresh Buttermilk, 200 ml", "Meadow Dairy Coop", "P. Iyer", "17 Sep 2026, 10:14", "verify", 0],
  ["Amrut Gold Green Tea, 100 g", "Amrut Tea Estates", "A. Khan", "16 Sep 2026, 14:44", "verify", 0],
  ["Kesari Butter, 100 g", "Kesari Dairy Products", "S. Patil", "15 Sep 2026, 17:33", "verify", 0],
  ["Neelkamal Pasta, 500 g", "Neelkamal Foods", "N. Joshi", "14 Sep 2026, 13:20", "flag", 1],
  ["Sparkle Hand Wash, 250 ml", "Sparkle Home Care", "R. Mehta", "13 Sep 2026, 11:08", "verify", 0],
  ["Royal Chakki Sooji, 1 kg", "Royal Mills Ltd", "P. Iyer", "12 Sep 2026, 15:41", "flag", 1],
  ["Village Jaggery Cubes, 500 g", "Village Agro Foods", "A. Khan", "11 Sep 2026, 10:05", "verify", 0],
];

/* "28 Sep 2026, 11:42" -> epoch ms (used for sorting) */
function parseScanDate(str) {
  const m = str.match(/(\d{1,2}) (\w{3}) (\d{4}), (\d{2}):(\d{2})/);
  const months = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
  return new Date(+m[3], months[m[2]], +m[1], +m[4], +m[5]).getTime();
}

const SCANS = [
  ...SCANS_FEATURED,
  ...SCANS_OLDER.map((r, i) => ({
    id: "SCAN-" + (10226 - i),
    product: r[0], manufacturer: r[1], officer: r[2], date: r[3], status: r[4], issues: r[5],
  })),
].map((s) => ({ ...s, ts: parseScanDate(s.date) }));

/* Full field-level reports for the three scans the demo lets you open
   end-to-end (compliant / violation / re-inspection cases). */
const REPORTS = {
  "SCAN-10234": {
    product: "Sunrise Refined Sunflower Oil, 1 L",
    manufacturer: "Sunrise Agro Pvt Ltd, MIDC, Nashik - 422010",
    officer: OFFICER,
    location: "Kirana Bazaar, FC Road, Pune",
    scannedAt: "28 Sep 2026, 11:42 IST",
    calibration: "ArUco fallback — no barcode match",
    captureHash: "a43f9c21e7b6d84a1f02…c9d02f",
    reportHash: "7b1e4a8d9c3f55e2a0b1…1055a1",
    status: "flag",
    fields: [
      { name: "MRP", value: "₹189.00", required: "4.0 mm min", measured: "2.6 mm", status: "flag", note: "Numeral height below the Rule 7 minimum for this panel area." },
      { name: "Net Quantity", value: "1 Litre", required: "4.0 mm min", measured: "4.2 mm", status: "verify", note: "" },
      { name: "Mfg / Packing Date", value: "07/2026", required: "Legible", measured: "OCR conf. 0.91", status: "verify", note: "" },
      { name: "Manufacturer Address", value: "Sunrise Agro Pvt Ltd, MIDC, Nashik", required: "Present", measured: "Found — back panel", status: "verify", note: "" },
      { name: "Consumer Care", value: "—", required: "Present", measured: "Not detected", status: "flag", note: "No match on front or back panel." },
      { name: "Country of Origin", value: "India", required: "Present", measured: "Found — front panel", status: "verify", note: "" },
    ],
    summary: [
      "MRP numeral height measures 2.6 mm against a 4 mm minimum required for this package's display-panel area under Rule 7.",
      "Consumer care details could not be located on either the front or back panel.",
    ],
  },

  "SCAN-10233": {
    product: "Tanishq Basmati Rice, 5 kg",
    manufacturer: "Tanishq Foods Pvt Ltd, Karnal, Haryana - 132001",
    officer: OFFICER,
    location: "Kirana Bazaar, FC Road, Pune",
    scannedAt: "28 Sep 2026, 10:15 IST",
    calibration: "DataKart — barcode matched",
    captureHash: "e91ac04fd2b7813c56a0…77f4b2",
    reportHash: "2c5d8e1f9a4b60d37e12…0a93cc",
    status: "verify",
    fields: [
      { name: "MRP", value: "₹540.00", required: "4.0 mm min", measured: "4.8 mm", status: "verify", note: "" },
      { name: "Net Quantity", value: "5 kg", required: "4.0 mm min", measured: "5.1 mm", status: "verify", note: "" },
      { name: "Mfg / Packing Date", value: "06/2026", required: "Legible", measured: "OCR conf. 0.97", status: "verify", note: "" },
      { name: "Manufacturer Address", value: "Tanishq Foods Pvt Ltd, Karnal", required: "Present", measured: "Found — back panel", status: "verify", note: "" },
      { name: "Consumer Care", value: "care@tanishqfoods.in", required: "Present", measured: "Found — back panel", status: "verify", note: "" },
      { name: "Country of Origin", value: "India", required: "Present", measured: "Found — front panel", status: "verify", note: "" },
    ],
    summary: ["All mandatory declarations detected, anchored, and within required font-height thresholds."],
  },

  "SCAN-10232": {
    product: "Shudh Toor Dal, 1 kg",
    manufacturer: "Shudh Grains Co., Latur, Maharashtra",
    officer: { name: "A. Khan", id: "LM-OFF-1187", station: "Pune Circle Office" },
    location: "Annapurna Kirana Stores, Kothrud, Pune",
    scannedAt: "27 Sep 2026, 16:30 IST",
    calibration: "ArUco fallback — no barcode match",
    captureHash: "5f3b7d19ac2e048f91d6…e8c741",
    reportHash: "991c2a7e04bd5f83a2c0…b64d19",
    status: "brass",
    fields: [
      { name: "MRP", value: "₹118.00", required: "4.0 mm min", measured: "4.3 mm", status: "verify", note: "" },
      { name: "Net Quantity", value: "1 kg (unclear)", required: "4.0 mm min", measured: "OCR conf. 0.52", status: "brass", note: "Print smudged near the net-quantity declaration — re-inspection recommended." },
      { name: "Mfg / Packing Date", value: "08/2026", required: "Legible", measured: "OCR conf. 0.88", status: "verify", note: "" },
      { name: "Manufacturer Address", value: "Shudh Grains Co., Latur", required: "Present", measured: "Found — back panel", status: "verify", note: "" },
      { name: "Consumer Care", value: "1800-212-4040", required: "Present", measured: "Found — back panel", status: "verify", note: "" },
      { name: "Country of Origin", value: "India", required: "Present", measured: "Found — front panel", status: "verify", note: "" },
    ],
    summary: ["Net-quantity text falls below the OCR confidence threshold — flagged for manual re-inspection rather than an automatic pass or fail."],
  },
};


/* ==========================================================================
   Dashboard datasets
   ========================================================================== */

/* Deterministic pseudo-random so the charts look the same on every load. */
function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

/* 180 days of daily inspections/violations ending 28 Sep 2026. The most recent
   30 days are calibrated to total exactly 1,248 inspections and 187 violations. */
const DAILY_SERIES = (function buildDailySeries() {
  const rnd = seededRandom(26034);
  const DAYS = 180;
  const end = new Date(2026, 8, 28);
  const rows = [];

  for (let i = 0; i < DAYS; i++) {
    const d = new Date(end);
    d.setDate(end.getDate() - (DAYS - 1 - i));
    const t = i / (DAYS - 1);
    const dow = d.getDay();
    const dayFactor = dow === 0 ? 0.35 : dow === 6 ? 0.8 : 1;
    const growth = 0.7 + 0.5 * t;                       // adoption ramps up
    const raw = 36 * growth * dayFactor * (0.85 + rnd() * 0.3);
    const vRate = 0.235 - 0.09 * t + (rnd() - 0.5) * 0.03; // violation rate improves
    rows.push({ date: d, raw, vRate, inspections: 0, violations: 0 });
  }

  const last30 = rows.slice(-30);
  const factor = 1248 / last30.reduce((a, r) => a + r.raw, 0);
  rows.forEach((r) => { r.inspections = Math.max(4, Math.round(r.raw * factor)); });

  function settle(key, target, canStep) {
    let diff = target - last30.reduce((a, r) => a + r[key], 0);
    let guard = 0;
    for (let i = last30.length - 1; diff !== 0 && guard < 5000; i = (i - 1 + last30.length) % last30.length, guard++) {
      const step = diff > 0 ? 1 : -1;
      if (canStep(last30[i], step)) { last30[i][key] += step; diff -= step; }
    }
  }

  settle("inspections", 1248, (r, st) => r.inspections + st >= 4);
  rows.forEach((r) => { r.violations = Math.min(r.inspections, Math.max(0, Math.round(r.inspections * r.vRate))); });
  settle("violations", 187, (r, st) => r.violations + st >= 0 && r.violations + st <= r.inspections);

  return rows.map(({ date, inspections, violations }) => ({ date, inspections, violations }));
})();

/* Circle-office breakdown for the last 30 days (sums to 1,248 / 187). */
const REGIONS = [
  { name: "Pune",                      inspections: 392, violations: 52 },
  { name: "Mumbai",                    inspections: 318, violations: 54 },
  { name: "Nagpur",                    inspections: 187, violations: 27 },
  { name: "Nashik",                    inspections: 142, violations: 21 },
  { name: "Chh. Sambhajinagar",        inspections: 121, violations: 20 },
  { name: "Kolhapur",                  inspections: 88,  violations: 13 },
];

/* Repeat offenders, last 30 days. */
const TOP_MANUFACTURERS = [
  { name: "Royal Mills Ltd",       violations: 9, topIssue: "MRP font too small" },
  { name: "Sunrise Agro Pvt Ltd",  violations: 7, topIssue: "MRP font too small" },
  { name: "Sparkle Home Care",     violations: 6, topIssue: "Net quantity — unit missing" },
  { name: "Pure Drop Beverages",   violations: 5, topIssue: "Mfg/packing date unreadable" },
  { name: "Golden Harvest Foods",  violations: 4, topIssue: "Manufacturer address missing" },
];

/* ==========================================================================
   Report lookup — 3 scans have hand-written reports; every other scan in the
   list opens a templated report (same structure, flagged as illustrative).
   ========================================================================== */

const OFFICER_DIRECTORY = {
  "R. Mehta": OFFICER,
  "A. Khan":  { name: "A. Khan",  id: "LM-OFF-1187", station: "Pune Circle Office" },
  "P. Iyer":  { name: "P. Iyer",  id: "LM-OFF-1342", station: "Pune Circle Office" },
  "S. Patil": { name: "S. Patil", id: "LM-OFF-1456", station: "Pune Circle Office" },
  "N. Joshi": { name: "N. Joshi", id: "LM-OFF-1520", station: "Pune Circle Office" },
};

const REPORT_TEMPLATE_BY_STATUS = { verify: "SCAN-10233", flag: "SCAN-10234", brass: "SCAN-10232" };

function pseudoHash(seed, len) {
  const rnd = seededRandom([...seed].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7));
  let out = "";
  while (out.length < len) out += Math.floor(rnd() * 16).toString(16);
  return out;
}

function getReport(id) {
  if (REPORTS[id]) return REPORTS[id];
  const scan = SCANS.find((s) => s.id === id);
  if (!scan) return null;
  const base = REPORTS[REPORT_TEMPLATE_BY_STATUS[scan.status]];
  const officer = OFFICER_DIRECTORY[scan.officer] || { name: scan.officer, id: "LM-OFF-0000", station: "Pune Circle Office" };
  return {
    ...base,
    product: scan.product,
    manufacturer: scan.manufacturer,
    officer,
    location: "Field inspection · " + officer.station,
    scannedAt: scan.date + " IST",
    captureHash: pseudoHash(id + "c", 20) + "…" + pseudoHash(id + "C", 6),
    reportHash: pseudoHash(id + "r", 20) + "…" + pseudoHash(id + "R", 6),
    templated: true,
  };
}
