/* ==========================================================================
   LabelGuard — shared app shell (session, navbar, small icon set)
   No backend: "session" is just localStorage, reset any time via Logout.
   ========================================================================== */

const ICONS = {
  officer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.5" r="3.2"/><path d="M5 20c0-3.6 3.1-6.2 7-6.2s7 2.6 7 6.2"/><path d="M15.5 9.2l1.6-1 1.6 1v2.1c0 1.6-1 2.8-1.6 3.1-.6-.3-1.6-1.5-1.6-3.1V9.2z"/></svg>',
  landmark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10h16"/><path d="M4 20h16"/><path d="M6 10v8"/><path d="M10 10v8"/><path d="M14 10v8"/><path d="M18 10v8"/><path d="M3 10l9-5 9 5"/></svg>',
  camera: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1-1.6h7l1 1.6h2A1.5 1.5 0 0 1 20 8.5v9A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.5" r="3.4"/></svg>',
  upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V4"/><path d="M8 8l4-4 4 4"/><path d="M4 16v2.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V16"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 7"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.3-4.3"/></svg>',
  grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></svg>',
};

/* Extra icons used by the dashboard (same 24px stroke style as above) */
const _ico = (inner, sw = 1.8) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;

Object.assign(ICONS, {
  clipboard: _ico('<rect x="6" y="5" width="12" height="15" rx="2"/><path d="M9 5.5V4h6v1.5"/><path d="M9 11h6M9 15h4"/>'),
  alert: _ico('<path d="M12 4.5l8.5 15h-17z"/><path d="M12 10v4"/><circle cx="12" cy="16.8" r=".6" fill="currentColor"/>'),
  shield: _ico('<path d="M12 3.5l7 2.8v5.4c0 4.2-2.9 7.6-7 8.8-4.1-1.2-7-4.6-7-8.8V6.3z"/><path d="M8.8 12l2.3 2.3 4.2-4.4"/>'),
  users: _ico('<circle cx="9" cy="9" r="3"/><path d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5"/><path d="M15.5 6.4a3 3 0 0 1 0 5.4"/><path d="M17 14.2c2 .5 3.5 2.2 3.5 4.8"/>'),
  clock: _ico('<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>'),
  download: _ico('<path d="M12 4v11"/><path d="M8 11l4 4 4-4"/><path d="M4 16v2.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V16"/>'),
  pin: _ico('<path d="M12 20s6-5.2 6-10a6 6 0 0 0-12 0c0 4.8 6 10 6 10z"/><circle cx="12" cy="10" r="2.2"/>'),
  building: _ico('<path d="M5 20V6l7-2.5V20"/><path d="M12 9l7 2v9"/><path d="M8.5 9h.01M8.5 12.5h.01M8.5 16h.01"/>'),
  sortUp: _ico('<path d="M7 14l5-5 5 5"/>', 2),
  sortDown: _ico('<path d="M7 10l5 5 5-5"/>', 2),
  sortBoth: _ico('<path d="M8 10l4-4 4 4"/><path d="M8 14l4 4 4-4"/>', 1.8),
  chevronLeft: _ico('<path d="M14.5 6l-6 6 6 6"/>', 2),
  chevronRight: _ico('<path d="M9.5 6l6 6-6 6"/>', 2),
});

function initials(name) {
  return name.split(" ").map((p) => p[0]).join(" ").replace(/\s/g, "").slice(0, 2).toUpperCase();
}

function getRole() {
  return localStorage.getItem("lg_role");
}

function setRole(role) {
  localStorage.setItem("lg_role", role);
}

function currentUser() {
  return getRole() === "ministry" ? MINISTRY_USER : OFFICER;
}

/* Where each role "lives" — used by the brand link and "back" buttons. */
function homeHref() {
  return getRole() === "ministry" ? "dashboard.html" : "capture.html";
}

function requireSession() {
  if (!getRole()) window.location.href = "index.html";
}

/* Send people to their own home if they open a page meant for the other role. */
function requireRole(role) {
  requireSession();
  const current = getRole();
  if (current && current !== role) window.location.href = homeHref();
}

function logout() {
  localStorage.removeItem("lg_role");
  window.location.href = "index.html";
}

function renderNavbar(activeKey) {
  const mount = document.getElementById("navbar");
  if (!mount) return;
  const user = currentUser();
  const isMinistry = getRole() === "ministry";

  /* Each role only sees the screens that are meant for them. */
  const links = isMinistry
    ? `<a href="dashboard.html" class="nav-link ${activeKey === "dashboard" ? "active" : ""}">Ministry dashboard</a>`
    : `<a href="capture.html" class="nav-link ${activeKey === "capture" ? "active" : ""}">Scan product</a>`;

  mount.innerHTML = `
    <div class="container">
      <a href="${homeHref()}" class="brand">
        <span class="brand-mark"></span>
        <span class="brand-name">LabelGuard</span>
      </a>
      <div class="nav-links">${links}</div>
      <div class="nav-right">
        <span class="proto-pill">Prototype v1.0</span>
        <div class="user-chip">
          <span class="user-avatar">${initials(user.name)}</span>
          <span class="user-meta">
            <span class="user-name">${user.name}</span>
            <span class="user-role">${isMinistry ? "Ministry Official" : "Field Officer"}</span>
          </span>
        </div>
        <a href="#" class="logout-link" onclick="logout(); return false;">Sign out</a>
      </div>
    </div>
  `;

  renderFooter();
}

function renderFooter() {
  if (document.getElementById("siteFooter")) return;
  const el = document.createElement("footer");
  el.id = "siteFooter";
  el.className = "site-footer no-print";
  el.innerHTML = `
    <div class="container">
      <span>Legal Metrology (Packaged Commodities) Rules, 2011 · Department of Consumer Affairs</span>
      <span class="mono">LabelGuard · Prototype v1.0 · Smart India Hackathon 2026 (PS 26034)</span>
    </div>`;
  document.body.appendChild(el);
}
