/* ==========================================================================
   LabelGuard — ministry dashboard
   Everything on this page is computed from the hardcoded datasets in data.js,
   so the date-range switch, filters, sorting and CSV export all really work.
   ========================================================================== */

requireRole("ministry");
renderNavbar("dashboard");

const STATUS_META = {
  verify: { label: "Compliant", pillClass: "pill-verify", severity: 2 },
  flag: { label: "Violations found", pillClass: "pill-flag", severity: 0 },
  brass: { label: "Needs re-inspection", pillClass: "pill-brass", severity: 1 },
};

const PAGE_SIZE = 8;
const state = { range: 30, page: 1, sortKey: "date", sortDir: "desc" };

/* ---------- small helpers ---------- */

const sum = (arr, key) => arr.reduce((a, x) => a + x[key], 0);
const fmt = (n) => Math.round(n).toLocaleString("en-IN");
const fmtDay = (d) => d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });

function pillHtml(meta) {
  return `<span class="pill ${meta.pillClass}"><span class="pill-dot"></span>${meta.label}</span>`;
}

/* current period (offset 0) or the equally long period before it (offset 1) */
function periodSlice(range, offset = 0) {
  const end = DAILY_SERIES.length - offset * range;
  return DAILY_SERIES.slice(end - range, end);
}

/* scale the 30-day reference datasets (regions, manufacturers) to the chosen range */
function rangeFactor() {
  return sum(periodSlice(state.range), "inspections") / 1248;
}

/* ---------- 1. headline stat cards ---------- */

function deltaChip(change, unit, goodWhen) {
  if (!change || Math.abs(change) < 0.05) return `<span class="stat-delta flat">— no change</span>`;
  const up = change > 0;
  const good = up === (goodWhen === "up");
  const arrow = up ? "▲" : "▼";
  return `<span class="stat-delta ${good ? "good" : "bad"}">${arrow} ${Math.abs(change).toFixed(unit === "%" || unit === "pp" ? 1 : 0)}${unit === "s" ? "s" : unit === "pp" ? " pp" : unit === "n" ? "" : "%"}</span>`;
}

function statCard({ icon, value, label, chip, foot, tone }) {
  return `
    <div class="stat-card ${tone ? "stat-card--" + tone : ""}">
      <div class="stat-top"><span class="stat-icon">${icon}</span>${chip}</div>
      <div class="stat-value">${value}</div>
      <div class="stat-label">${label}</div>
      <div class="stat-foot">${foot}</div>
    </div>`;
}

function renderStats() {
  const r = state.range;
  const cur = periodSlice(r), prev = periodSlice(r, 1);
  const ci = sum(cur, "inspections"), cv = sum(cur, "violations");
  const pi = sum(prev, "inspections"), pv = sum(prev, "violations");
  const rate = 100 - (cv / ci) * 100, prate = 100 - (pv / pi) * 100;
  const meta = RANGE_META[r];
  const vs = `vs previous ${r} days`;

  document.getElementById("statGrid").innerHTML = [
    statCard({ icon: ICONS.clipboard, value: fmt(ci), label: "Total inspections", foot: vs, chip: deltaChip(((ci - pi) / pi) * 100, "%", "up") }),
    statCard({ icon: ICONS.alert, value: fmt(cv), label: "Violations flagged", foot: vs, tone: "flag", chip: deltaChip(((cv - pv) / pv) * 100, "%", "down") }),
    statCard({ icon: ICONS.shield, value: rate.toFixed(1) + "%", label: "Compliance rate", foot: vs, tone: "verify", chip: deltaChip(rate - prate, "pp", "up") }),
    statCard({ icon: ICONS.users, value: meta.officers, label: "Active field officers", foot: vs, chip: deltaChip(meta.officersDelta, "n", "up") }),
    statCard({ icon: ICONS.clock, value: meta.scanSecs + "s", label: "Avg. scan time", foot: vs, chip: deltaChip(meta.scanSecsDelta, "s", "down") }),
  ].join("");
}

/* ---------- 2. trend chart (inline SVG, with hover tooltip) ---------- */

function bucketSeries(series, size) {
  const out = [];
  for (let i = 0; i < series.length; i += size) {
    const chunk = series.slice(i, i + size);
    out.push({
      start: chunk[0].date,
      end: chunk[chunk.length - 1].date,
      inspections: sum(chunk, "inspections"),
      violations: sum(chunk, "violations"),
    });
  }
  return out;
}

function niceStep(max, ticks) {
  const raw = max / ticks;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * pow;
}

function renderTrend() {
  const series = periodSlice(state.range);
  const size = state.range > 60 ? 3 : 1;
  const pts = bucketSeries(series, size);

  document.getElementById("trendSub").textContent =
    `${fmtDay(series[0].date)} – ${fmtDay(series[series.length - 1].date)} 2026 · ${size === 1 ? "daily" : "3-day totals"}`;
  document.getElementById("trendLegend").innerHTML = `
    <span class="legend-item"><span class="legend-swatch" style="background:var(--steel)"></span>Inspections <b>${fmt(sum(series, "inspections"))}</b></span>
    <span class="legend-item"><span class="legend-swatch" style="background:var(--flag)"></span>Violations <b>${fmt(sum(series, "violations"))}</b></span>`;

  const W = 720, H = 270, L = 44, R = 14, T = 14, B = 30;
  const iw = W - L - R, ih = H - T - B;
  const step = niceStep(Math.max(...pts.map((p) => p.inspections)), 4);
  const yMax = step * 4;
  const x = (i) => L + (pts.length === 1 ? iw / 2 : (i * iw) / (pts.length - 1));
  const y = (v) => T + ih - (v / yMax) * ih;
  const line = (key) => pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p[key]).toFixed(1)}`).join(" ");
  const area = (key) => `${line(key)} L${x(pts.length - 1).toFixed(1)},${T + ih} L${x(0).toFixed(1)},${T + ih} Z`;

  let grid = "";
  for (let k = 0; k <= 4; k++) {
    const v = step * k, yy = y(v);
    grid += `<line class="grid-line" x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}"/>
             <text class="axis-text" x="${L - 8}" y="${yy + 4}" text-anchor="end">${v}</text>`;
  }

  const labelCount = state.range === 7 ? pts.length : 6;
  let xlabels = "";
  for (let k = 0; k < labelCount; k++) {
    const idx = labelCount === 1 ? 0 : Math.round((k * (pts.length - 1)) / (labelCount - 1));
    xlabels += `<text class="axis-text" x="${x(idx)}" y="${H - 8}" text-anchor="${k === 0 ? "start" : k === labelCount - 1 ? "end" : "middle"}">${fmtDay(pts[idx].start)}</text>`;
  }

  const markers = pts.length <= 14
    ? pts.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.inspections)}" r="3" fill="var(--steel)"/><circle cx="${x(i)}" cy="${y(p.violations)}" r="3" fill="var(--flag)"/>`).join("")
    : "";

  const wrap = document.getElementById("trendChart");
  wrap.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Line chart of inspections and violations over time">
      <defs>
        <linearGradient id="gInsp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--steel);stop-opacity:.22"/><stop offset="1" style="stop-color:var(--steel);stop-opacity:0"/></linearGradient>
        <linearGradient id="gViol" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--flag);stop-opacity:.22"/><stop offset="1" style="stop-color:var(--flag);stop-opacity:0"/></linearGradient>
      </defs>
      ${grid}${xlabels}
      <path d="${area("inspections")}" fill="url(#gInsp)"/>
      <path d="${area("violations")}" fill="url(#gViol)"/>
      <path d="${line("inspections")}" fill="none" stroke="var(--steel)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
      <path d="${line("violations")}" fill="none" stroke="var(--flag)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
      ${markers}
      <line class="guide" id="ttGuide" x1="0" x2="0" y1="${T}" y2="${T + ih}"/>
      <circle class="hover-dot" id="ttDotA" r="4.5" fill="#fff" stroke="var(--steel)" stroke-width="2"/>
      <circle class="hover-dot" id="ttDotB" r="4.5" fill="#fff" stroke="var(--flag)" stroke-width="2"/>
      <rect id="ttHit" x="${L}" y="${T}" width="${iw}" height="${ih}" fill="transparent"/>
    </svg>
    <div class="chart-tooltip" id="chartTip"></div>`;

  const svg = wrap.querySelector("svg"), hit = wrap.querySelector("#ttHit"), tip = wrap.querySelector("#chartTip");
  const guide = wrap.querySelector("#ttGuide"), dotA = wrap.querySelector("#ttDotA"), dotB = wrap.querySelector("#ttDotB");

  function onMove(e) {
    const rect = svg.getBoundingClientRect();
    const px = ((e.clientX - rect.left) * W) / rect.width;
    const idx = Math.max(0, Math.min(pts.length - 1, Math.round(((px - L) / iw) * (pts.length - 1))));
    const p = pts[idx];
    guide.setAttribute("x1", x(idx)); guide.setAttribute("x2", x(idx));
    dotA.setAttribute("cx", x(idx)); dotA.setAttribute("cy", y(p.inspections));
    dotB.setAttribute("cx", x(idx)); dotB.setAttribute("cy", y(p.violations));
    const when = size === 1 ? fmtDay(p.start) : `${fmtDay(p.start)} – ${fmtDay(p.end)}`;
    tip.innerHTML = `<div class="tt-date">${when}</div>
      <div><span class="tt-dot" style="background:#9fb7d1"></span>Inspections: <b>${p.inspections}</b></div>
      <div><span class="tt-dot" style="background:#f0a58d"></span>Violations: <b>${p.violations}</b> (${((p.violations / p.inspections) * 100).toFixed(1)}%)</div>`;
    const left = (x(idx) / W) * rect.width;
    tip.style.left = left > rect.width * 0.65 ? `${left - tip.offsetWidth - 12}px` : `${left + 12}px`;
    wrap.classList.add("is-hover");
  }
  hit.addEventListener("pointermove", onMove);
  hit.addEventListener("pointerdown", onMove);
  hit.addEventListener("pointerleave", () => wrap.classList.remove("is-hover"));
}

/* ---------- 3. violation categories ---------- */

function renderCategories() {
  const cv = sum(periodSlice(state.range), "violations");
  document.getElementById("catSub").textContent = `${fmt(cv)} violations · last ${state.range} days`;
  const sorted = [...VIOLATION_CATEGORIES].sort((a, b) => b.pct - a.pct);
  document.getElementById("barChart").innerHTML = sorted.map((c, i) => `
    <div class="bar-item">
      <div class="bar-label-row"><span>${c.label}</span><span class="bar-value"><b>${fmt((c.pct / 100) * cv)}</b> · ${c.pct}%</span></div>
      <div class="bar-track"><div class="bar-fill ${i === 0 ? "bar-fill--top" : ""}" style="width:${c.pct}%"></div></div>
    </div>`).join("");
}

/* ---------- 4. regions + repeat offenders ---------- */

function renderRegions() {
  const f = rangeFactor();
  const rows = REGIONS.map((r) => ({
    name: r.name,
    insp: Math.round(r.inspections * f),
    viol: Math.round(r.violations * f),
  })).map((r) => ({ ...r, rate: (r.viol / r.insp) * 100 }));
  const worst = rows.reduce((a, b) => (b.rate > a.rate ? b : a)).name;
  rows.sort((a, b) => b.viol - a.viol);

  document.getElementById("regionList").innerHTML = `
    <div class="rank-head region-grid"><span>Circle office</span><span class="num">Inspections</span><span class="num">Violations</span><span>Violation rate</span></div>
    ${rows.map((r) => `
      <div class="rank-row region-grid">
        <span style="font-weight:600;">${r.name}${r.name === worst ? '<span class="tag-hi">Highest rate</span>' : ""}</span>
        <span class="num">${fmt(r.insp)}</span>
        <span class="num">${fmt(r.viol)}</span>
        <span class="rate-cell"><span class="rate-track"><span class="rate-fill ${r.name === worst ? "hi" : ""}" style="width:${Math.min(100, (r.rate / 25) * 100)}%"></span></span><span class="rate-text">${r.rate.toFixed(1)}%</span></span>
      </div>`).join("")}`;
}

function renderManufacturers() {
  const f = rangeFactor();
  document.getElementById("mfrList").innerHTML = TOP_MANUFACTURERS.map((m, i) => `
    <button class="rank-row rank-row--click mfr-grid" onclick="filterByManufacturer('${m.name.replace(/'/g, "\\'")}')">
      <span class="rank-num">${i + 1}</span>
      <span><span style="font-weight:600; display:block;">${m.name}</span><span class="text-sm text-faint">Most common: ${m.topIssue}</span></span>
      <span class="pill pill-flag"><span class="pill-dot"></span>${Math.max(1, Math.round(m.violations * f))} violations</span>
    </button>`).join("");
}

/* ---------- 5. inspections table ---------- */

const COLUMNS = [
  { key: "id", label: "Scan ID", sortable: false },
  { key: "product", label: "Product", sortable: true },
  { key: "officer", label: "Officer", sortable: true, cls: "hide-sm" },
  { key: "date", label: "Date", sortable: true, cls: "hide-sm" },
  { key: "issues", label: "Issues", sortable: true, cls: "hide-sm" },
  { key: "status", label: "Status", sortable: true, cls: "hide-sm" },
  { key: "action", label: "", sortable: false },
];

function sortIcon(key) {
  if (state.sortKey !== key) return ICONS.sortBoth;
  return state.sortDir === "asc" ? ICONS.sortUp : ICONS.sortDown;
}

function renderHead() {
  document.getElementById("scanHead").innerHTML = `
    <div class="scan-row scan-row--head">
      ${COLUMNS.map((c) => c.sortable
        ? `<div class="${c.cls || ""}"><button class="sort-btn ${state.sortKey === c.key ? "is-sorted" : ""}" onclick="setSort('${c.key}')">${c.label}${sortIcon(c.key)}</button></div>`
        : `<div class="${c.cls || ""}">${c.label}</div>`).join("")}
    </div>`;
}

function getRows() {
  const q = document.getElementById("searchInput").value.trim().toLowerCase();
  const status = document.getElementById("statusFilter").value;
  const dir = state.sortDir === "asc" ? 1 : -1;
  const val = (s) => {
    switch (state.sortKey) {
      case "date": return s.ts;
      case "issues": return s.issues;
      case "status": return STATUS_META[s.status].severity;
      default: return String(s[state.sortKey]).toLowerCase();
    }
  };
  return SCANS
    .filter((s) => (status === "all" || s.status === status) &&
      (!q || [s.id, s.product, s.manufacturer, s.officer].some((t) => t.toLowerCase().includes(q))))
    .sort((a, b) => (val(a) > val(b) ? 1 : val(a) < val(b) ? -1 : b.ts - a.ts) * dir);
}

function renderTable() {
  renderHead();
  const rows = getRows();
  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  state.page = Math.min(state.page, pages);
  const startIdx = (state.page - 1) * PAGE_SIZE;
  const view = rows.slice(startIdx, startIdx + PAGE_SIZE);

  document.getElementById("scanBody").innerHTML = view.length
    ? view.map((s) => `
      <a class="scan-row" href="report.html?id=${s.id}">
        <div class="scan-id hide-sm">${s.id}</div>
        <div><div style="font-weight:600;">${s.product}</div><div class="text-sm text-faint">${s.manufacturer}</div></div>
        <div class="text-sm hide-sm">${s.officer}</div>
        <div class="text-sm hide-sm">${s.date}</div>
        <div class="hide-sm"><span class="issues-badge ${s.issues ? "has-issues" : ""}">${s.issues}</span></div>
        <div class="hide-sm">${pillHtml(STATUS_META[s.status])}</div>
        <div style="text-align:right;"><span class="row-action">View →</span></div>
      </a>`).join("")
    : `<div class="empty-state"><h2>No inspections match</h2><p>Try a different search term or status filter.</p></div>`;

  document.getElementById("tableCount").textContent = rows.length
    ? `Showing ${startIdx + 1}–${startIdx + view.length} of ${rows.length} inspections`
    : "Showing 0 inspections";

  const btn = (label, page, { disabled, active } = {}) =>
    `<button class="page-btn ${active ? "is-active" : ""}" ${disabled ? "disabled" : ""} onclick="goPage(${page})">${label}</button>`;
  let pager = btn(ICONS.chevronLeft, state.page - 1, { disabled: state.page === 1 });
  for (let p = 1; p <= pages; p++) pager += btn(p, p, { active: p === state.page });
  pager += btn(ICONS.chevronRight, state.page + 1, { disabled: state.page === pages });
  document.getElementById("pager").innerHTML = pages > 1 ? pager : "";
}

function goPage(p) { state.page = p; renderTable(); }

function setSort(key) {
  if (state.sortKey === key) state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
  else { state.sortKey = key; state.sortDir = key === "product" || key === "officer" ? "asc" : "desc"; }
  state.page = 1;
  renderTable();
}

function onFilterChange() { state.page = 1; renderTable(); }

function filterByManufacturer(name) {
  document.getElementById("searchInput").value = name;
  document.getElementById("statusFilter").value = "all";
  state.page = 1;
  renderTable();
  document.getElementById("inspections").scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ---------- export (current filtered + sorted view) ---------- */

function exportCsv() {
  const header = ["Scan ID", "Product", "Manufacturer", "Officer", "Date", "Status", "Issues"];
  const esc = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [header.map(esc).join(",")].concat(
    getRows().map((s) => [s.id, s.product, s.manufacturer, s.officer, s.date, STATUS_META[s.status].label, s.issues].map(esc).join(","))
  );
  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "labelguard-inspections.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
}

/* ---------- range switch + first render ---------- */

function setRange(n) {
  state.range = n;
  document.querySelectorAll("#rangeControl button").forEach((b) => b.classList.toggle("is-active", +b.dataset.range === n));
  renderPeriodPanels();
}

function renderPeriodPanels() {
  renderStats();
  renderTrend();
  renderCategories();
  renderRegions();
  renderManufacturers();
}

function showSkeletons() {
  document.getElementById("statGrid").innerHTML = Array(5).fill(
    `<div class="stat-card"><span class="skeleton" style="height:32px;width:32px;margin-bottom:12px"></span><span class="skeleton" style="height:30px;width:60%;margin-bottom:8px"></span><span class="skeleton" style="height:12px;width:80%"></span></div>`).join("");
  document.getElementById("trendChart").innerHTML = `<span class="skeleton" style="height:260px;width:100%"></span>`;
  document.getElementById("barChart").innerHTML = Array(5).fill(`<span class="skeleton" style="height:28px;width:100%;margin-bottom:12px"></span>`).join("");
  document.getElementById("regionList").innerHTML = `<div style="padding:16px 20px">${Array(6).fill(`<span class="skeleton" style="height:22px;width:100%;margin-bottom:12px"></span>`).join("")}</div>`;
  document.getElementById("mfrList").innerHTML = `<div style="padding:16px 20px">${Array(5).fill(`<span class="skeleton" style="height:30px;width:100%;margin-bottom:12px"></span>`).join("")}</div>`;
  document.getElementById("scanBody").innerHTML = `<div style="padding:16px 20px">${Array(5).fill(`<span class="skeleton" style="height:26px;width:100%;margin-bottom:12px"></span>`).join("")}</div>`;
}

(function init() {
  document.getElementById("syncText").textContent = `Synced ${LAST_SYNC} · 0 pending uploads`;
  document.getElementById("exportBtn").innerHTML = `${ICONS.download}Export CSV`;
  document.getElementById("searchIcon").innerHTML = ICONS.search;
  showSkeletons();
  setTimeout(() => {
    renderPeriodPanels();
    renderTable();
  }, 450);
})();
